﻿using P04.BorderControl.Core;
using System;

namespace P04.BorderControl
{
    class StartUp
    {
        static void Main(string[] args)
        {
            var engine = new Engine();
            engine.Run();
        }
    }
}
