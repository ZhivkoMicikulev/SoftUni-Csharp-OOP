﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P04.BorderControl.Contracts
{
  public  interface IBirthdate
    {
        string Birthdate { get; }

    }
}
