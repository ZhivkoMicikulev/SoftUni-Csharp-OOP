﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P04.BorderControl.Contracts
{
    public interface IId
    {
        string Id { get; }
    }
}
