﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FoodStorage.Core.Contracts
{
 public   interface IEngine
    {
        void Run();
    }
}
