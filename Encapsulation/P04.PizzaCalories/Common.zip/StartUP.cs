﻿using P04.PizzaCalories.Core;
using P04.PizzaCalories.Models;
using System;
using System.Linq;

namespace P04.PizzaCalories
{
    class StartUP
    {
        static void Main(string[] args)
        {
            var engine = new Engine();
            engine.Run();
          

        }
    }
}
