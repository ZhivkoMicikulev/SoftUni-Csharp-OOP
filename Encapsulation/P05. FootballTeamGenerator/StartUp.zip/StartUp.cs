﻿using P05.FootballTeamGenerator.Core;
using System;

namespace P05.FootballTeamGenerator
{
    class StartUp
    {
        static void Main(string[] args)
        {
            var engine = new Engine();
            engine.Run();
        }
    }
}
