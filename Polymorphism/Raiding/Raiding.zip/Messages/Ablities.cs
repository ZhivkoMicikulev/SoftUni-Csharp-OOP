﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Raiding.Messages
{
  public static  class Ablities
    {
        public const string HEAILING_MSG =
            "{0} – {1} healed for {2}";

        public const string DAMAGE_MSG =
            "{0} – {1} hit for {2} damage";


    }
}
