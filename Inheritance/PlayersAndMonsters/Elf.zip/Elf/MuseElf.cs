﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PlayersAndMonsters.Elf
{
    public class MuseElf : Elf
    {
        public MuseElf(string username, int level)
            : base(username, level)
        {

        }
    }
}
